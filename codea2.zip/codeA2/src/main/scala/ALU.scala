import chisel3._
import chisel3.util._

class ALU extends Module {
  val io = IO(new Bundle {
    //Define the module interface here (inputs/outputs)
    val op1 = Input(UInt(32.W))
    val op2 = Input(UInt(32.W))
    val sel = Input(UInt(3.W))
    val res = Output(UInt(32.W))
    val com_res = Output(Bool())
  })

  io.res := 0.U
  io.com_res := false.B

  //Implement this module here
  switch(io.sel){
    is(0.U){io.res := io.op1 + io.op2}
    is(1.U){io.res := io.op1 | io.op2}
    is(2.U){io.com_res := io.op1 === io.op2}
  }
}