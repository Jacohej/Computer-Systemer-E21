import chisel3._
import chisel3.util._

class ControlUnit extends Module {
  val io = IO(new Bundle {
    val opcode = Input(UInt(3.W))
    val writeData = Output(Bool())
    val aluOP = Output(UInt(3.W))
    val ImmOrReg = Output(Bool())
    val memoryRead = Output(Bool())
    val memoryWrite = Output(Bool())
    val memoryOrAlu = Output(Bool())
    val jump = Output(Bool())
    val run = Output(Bool())
    val stop = Output(Bool())
  })

  io.stop := false.B

  io.ImmOrReg := false.B
  io.jump := false.B
  io.memoryOrAlu := false.B
  io.writeData := false.B
  io.run := true.B
  io.aluOP := 0.U
  io.memoryRead := false.B
  io.memoryWrite := false.B
  //Implement this module here

  //Taking the 3 first bits from the opcode
  switch(io.opcode){
    is(0.U){io.aluOP := 0.U
      io.jump := false.B
      io.memoryWrite := false.B
      io.memoryRead := false.B
      io.ImmOrReg := false.B
    }
    is(1.U){io.aluOP := io.opcode
      io.ImmOrReg := true.B
    }
    is(2.U){io.aluOP := io.opcode}
    is(3.U){io.aluOP := io.opcode}
    is(4.U){io.jump := true.B}
    is(5.U){io.memoryWrite := true.B}
    is(6.U){io.memoryRead := true.B}
  }
}